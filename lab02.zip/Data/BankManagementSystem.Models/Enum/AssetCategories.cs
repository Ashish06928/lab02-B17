﻿namespace BankManagementSystem.Models.Enum
{
    public enum AssetCategories
    {
        Unspecified,
        RealEstate,
        CompanyEquity,
        Tangible,
        Land
    }
}
